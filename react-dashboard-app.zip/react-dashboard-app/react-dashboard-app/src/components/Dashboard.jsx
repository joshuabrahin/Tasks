import { useEffect, useState } from "react"
import { fetchUsers } from "../services/api"

function Dashboard() {
  const [users, setUsers] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchUsers().then((data) => {
      setUsers(data)
      setLoading(false)
    })
  }, [])

  if (loading) return <p className="dashboard">Loading...</p>

  return (
    <div className="dashboard">
      <h2>User Dashboard</h2>

      <div className="card-grid">
        {users.map((user) => (
          <div className="card" key={user.id}>
            <h3>{user.name}</h3>
            <p>{user.email}</p>
            <p>{user.address.city}</p>
          </div>
        ))}
      </div>
    </div>
  )
}

export default Dashboard

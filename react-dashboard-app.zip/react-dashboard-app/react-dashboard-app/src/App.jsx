import Dashboard from "./components/Dashboard"

function App() {
  return (
    <div>
      <h1>Dashboard App</h1>
      <Dashboard />
    </div>
  )
}

export default App
